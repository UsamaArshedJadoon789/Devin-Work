// Types
export interface User {
  id: string;
  name: string;
  email: string;
  role: 'chef' | 'foodie';
  profileImage?: string;
  bio?: string;
}

export interface Dish {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  chefId: string;
  isAvailable: boolean;
  category: string;
  preparationTime?: number;
  ingredients?: string[];
  rating?: number;
}

export interface Order {
  id: string;
  status: 'pending' | 'preparing' | 'delivering' | 'delivered' | 'cancelled';
  totalAmount: number;
  deliveryAddress: string;
  paymentMethod: string;
  paymentStatus: 'pending' | 'completed' | 'failed';
  createdAt: string;
  items: OrderItem[];
}

export interface OrderItem {
  id: string;
  dishId: string;
  dishName: string;
  quantity: number;
  price: number;
}

export interface Review {
  id: string;
  dishId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: string;
}

// Mock data
export const users: User[] = [
  {
    id: '1',
    name: 'Chef John',
    email: 'chef@example.com',
    role: 'chef',
    profileImage: '/images/chefs/photos/chef1.jpg',
    bio: 'Award-winning chef with 10 years of experience in Italian cuisine.'
  },
  {
    id: '2',
    name: 'Chef Maria',
    email: 'maria@example.com',
    role: 'chef',
    profileImage: '/images/chefs/photos/chef2.jpg',
    bio: 'Specializing in authentic Mexican dishes with a modern twist.'
  },
  {
    id: '3',
    name: 'Chef Alex',
    email: 'alex@example.com',
    role: 'chef',
    profileImage: '/images/chefs/photos/chef3.jpg',
    bio: 'Passionate about Asian fusion cuisine and innovative cooking techniques.'
  },
  {
    id: '4',
    name: 'Foodie Jane',
    email: 'foodie@example.com',
    role: 'foodie',
    profileImage: '/images/chefs/photos/foodie1.jpg',
    bio: 'Food enthusiast always looking for new culinary experiences.'
  }
];

export const dishes: Dish[] = [
  {
    id: '1',
    name: 'Spaghetti Carbonara',
    description: 'Creamy pasta with bacon and parmesan cheese',
    price: 12.99,
    imageUrl: '/images/dishes/photos/pasta_carbonara.jpg',
    chefId: '1',
    isAvailable: true,
    category: 'Italian',
    preparationTime: 20,
    ingredients: ['Spaghetti', 'Eggs', 'Bacon', 'Parmesan Cheese', 'Black Pepper'],
    rating: 4.8
  },
  {
    id: '2',
    name: 'Margherita Pizza',
    description: 'Classic pizza with tomato sauce, mozzarella, and basil',
    price: 10.99,
    imageUrl: '/images/dishes/photos/pizza_margherita.jpg',
    chefId: '1',
    isAvailable: true,
    category: 'Italian',
    preparationTime: 25,
    ingredients: ['Pizza Dough', 'Tomato Sauce', 'Mozzarella Cheese', 'Fresh Basil', 'Olive Oil'],
    rating: 4.5
  },
  {
    id: '3',
    name: 'Chicken Tikka Masala',
    description: 'Grilled chicken in a creamy tomato sauce with Indian spices',
    price: 14.99,
    imageUrl: '/images/dishes/photos/chicken_tikka.jpg',
    chefId: '2',
    isAvailable: true,
    category: 'Indian',
    preparationTime: 30,
    ingredients: ['Chicken', 'Yogurt', 'Tomato Sauce', 'Cream', 'Indian Spices'],
    rating: 4.7
  },
  {
    id: '4',
    name: 'Beef Burger',
    description: 'Juicy beef patty with lettuce, tomato, cheese, and special sauce',
    price: 9.99,
    imageUrl: '/images/dishes/photos/beef_burger.jpg',
    chefId: '2',
    isAvailable: true,
    category: 'American',
    preparationTime: 15,
    ingredients: ['Beef Patty', 'Burger Bun', 'Lettuce', 'Tomato', 'Cheese', 'Special Sauce'],
    rating: 4.6
  },
  {
    id: '5',
    name: 'Pad Thai',
    description: 'Stir-fried rice noodles with eggs, tofu, bean sprouts, and peanuts',
    price: 11.99,
    imageUrl: '/images/dishes/photos/pad_thai.jpg',
    chefId: '3',
    isAvailable: true,
    category: 'Thai',
    preparationTime: 20,
    ingredients: ['Rice Noodles', 'Eggs', 'Tofu', 'Bean Sprouts', 'Peanuts', 'Tamarind Sauce'],
    rating: 4.4
  },
  {
    id: '6',
    name: 'Sushi Platter',
    description: 'Assorted sushi rolls with fresh fish and vegetables',
    price: 18.99,
    imageUrl: '/images/dishes/photos/sushi_platter.jpg',
    chefId: '3',
    isAvailable: true,
    category: 'Japanese',
    preparationTime: 35,
    ingredients: ['Sushi Rice', 'Nori', 'Fresh Fish', 'Avocado', 'Cucumber', 'Soy Sauce'],
    rating: 4.9
  }
];

export const orders: Order[] = [
  {
    id: '1',
    status: 'delivered',
    totalAmount: 38.97,
    deliveryAddress: '123 Main St, Anytown, USA',
    paymentMethod: 'Credit Card',
    paymentStatus: 'completed',
    createdAt: '2025-02-25T14:30:00',
    items: [
      {
        id: '1',
        dishId: '1',
        dishName: 'Spaghetti Carbonara',
        quantity: 2,
        price: 12.99
      },
      {
        id: '2',
        dishId: '2',
        dishName: 'Margherita Pizza',
        quantity: 1,
        price: 10.99
      }
    ]
  },
  {
    id: '2',
    status: 'preparing',
    totalAmount: 14.99,
    deliveryAddress: '456 Oak St, Somewhere, USA',
    paymentMethod: 'PayPal',
    paymentStatus: 'completed',
    createdAt: '2025-02-28T10:15:00',
    items: [
      {
        id: '3',
        dishId: '3',
        dishName: 'Chicken Tikka Masala',
        quantity: 1,
        price: 14.99
      }
    ]
  }
];

export const reviews: Review[] = [
  {
    id: '1',
    dishId: '1',
    userId: '4',
    userName: 'Foodie Jane',
    rating: 4,
    comment: 'Delicious pasta! The sauce was creamy and flavorful.',
    createdAt: '2025-02-20T14:30:00'
  },
  {
    id: '2',
    dishId: '1',
    userId: '5',
    userName: 'John Smith',
    rating: 5,
    comment: 'Best carbonara I\'ve ever had! Will definitely order again.',
    createdAt: '2025-02-18T09:15:00'
  },
  {
    id: '3',
    dishId: '2',
    userId: '4',
    userName: 'Foodie Jane',
    rating: 5,
    comment: 'Perfect pizza! The crust was just right and the toppings were fresh.',
    createdAt: '2025-02-22T18:45:00'
  }
];
