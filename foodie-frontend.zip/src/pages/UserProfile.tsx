import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, Edit, MapPin, Phone, Mail, Calendar, ShoppingBag } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { orders } from '../data/mockData';

const UserProfile: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('orders');
  
  // If not logged in or not a foodie, show error
  if (!user || user.role !== 'foodie') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Access Denied</h2>
          <p className="text-gray-600 mb-6">You need to be logged in as a foodie to view this page.</p>
          <Link 
            to="/login" 
            className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-md font-medium transition-colors duration-200"
          >
            Login as Foodie
          </Link>
        </div>
      </div>
    );
  }

  // For demo purposes, we'll just use all orders since we don't have userId in the Order interface
  const userOrders = orders;
  
  // Calculate stats
  const totalOrders = userOrders.length;
  const totalSpent = userOrders.reduce((sum, order) => sum + order.totalAmount, 0);
  const favoriteCategory = "Italian"; // Mock data
  
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* User Profile Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white rounded-lg shadow-md overflow-hidden mb-8"
        >
          <div className="bg-gradient-to-r from-blue-500 to-purple-500 h-32 md:h-48"></div>
          <div className="px-6 py-6 md:flex md:items-center md:justify-between">
            <div className="flex items-center">
              <div className="relative -mt-16">
                <img 
                  src={user.profileImage} 
                  alt={user.name} 
                  className="w-24 h-24 rounded-full border-4 border-white object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = '/images/foodies/foodie1.svg';
                  }}
                />
              </div>
              <div className="ml-4 -mt-10 md:mt-0">
                <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
                <p className="text-gray-600">Food Enthusiast</p>
                <div className="flex items-center mt-1">
                  <div className="flex items-center text-yellow-500">
                    <Star className="w-4 h-4 fill-current" />
                    <Star className="w-4 h-4 fill-current" />
                    <Star className="w-4 h-4 fill-current" />
                    <Star className="w-4 h-4 fill-current" />
                    <Star className="w-4 h-4 fill-current" />
                  </div>
                  <span className="ml-1 text-sm text-gray-600">5.0 (24 reviews)</span>
                </div>
              </div>
            </div>
            <div className="mt-6 md:mt-0">
              <Link 
                to="/profile/edit" 
                className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors duration-200"
              >
                <Edit className="w-4 h-4 mr-2" />
                Edit Profile
              </Link>
            </div>
          </div>
        </motion.div>
        
        {/* User Info Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="bg-white rounded-lg shadow-md overflow-hidden mb-8"
        >
          <div className="px-6 py-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Personal Information</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-start">
                <MapPin className="w-5 h-5 text-gray-500 mt-0.5 mr-3" />
                <div>
                  <p className="text-sm text-gray-500 mb-1">Address</p>
                  <p className="text-gray-800">123 Main Street, Apt 4B</p>
                  <p className="text-gray-800">New York, NY 10001</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Phone className="w-5 h-5 text-gray-500 mt-0.5 mr-3" />
                <div>
                  <p className="text-sm text-gray-500 mb-1">Phone</p>
                  <p className="text-gray-800">+1 (555) 123-4567</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Mail className="w-5 h-5 text-gray-500 mt-0.5 mr-3" />
                <div>
                  <p className="text-sm text-gray-500 mb-1">Email</p>
                  <p className="text-gray-800">{user.email}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Calendar className="w-5 h-5 text-gray-500 mt-0.5 mr-3" />
                <div>
                  <p className="text-sm text-gray-500 mb-1">Member Since</p>
                  <p className="text-gray-800">January 15, 2025</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* Stats Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-white rounded-lg shadow-md overflow-hidden mb-8"
        >
          <div className="px-6 py-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Your Stats</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Total Orders</p>
                <div className="flex items-center">
                  <ShoppingBag className="w-5 h-5 text-blue-500 mr-2" />
                  <p className="text-2xl font-bold text-gray-900">{totalOrders}</p>
                </div>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Total Spent</p>
                <p className="text-2xl font-bold text-gray-900">${totalSpent.toFixed(2)}</p>
              </div>
              
              <div className="bg-purple-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Favorite Cuisine</p>
                <p className="text-2xl font-bold text-gray-900">{favoriteCategory}</p>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* Tabs Section */}
        <div className="mb-6">
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab('orders')}
              className={`py-3 px-6 text-sm font-medium ${
                activeTab === 'orders'
                  ? 'text-orange-500 border-b-2 border-orange-500'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Order History
            </button>
            <button
              onClick={() => setActiveTab('favorites')}
              className={`py-3 px-6 text-sm font-medium ${
                activeTab === 'favorites'
                  ? 'text-orange-500 border-b-2 border-orange-500'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Favorite Dishes
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className={`py-3 px-6 text-sm font-medium ${
                activeTab === 'reviews'
                  ? 'text-orange-500 border-b-2 border-orange-500'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              My Reviews
            </button>
          </div>
        </div>
        
        {/* Tab Content */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {activeTab === 'orders' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="p-6"
            >
              <h2 className="text-xl font-bold text-gray-900 mb-6">Order History</h2>
              
              {userOrders.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-gray-500 mb-4">You haven't placed any orders yet.</p>
                  <Link 
                    to="/dishes" 
                    className="inline-flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-500 hover:bg-orange-600 transition-colors duration-200"
                  >
                    Browse Dishes
                  </Link>
                </div>
              ) : (
                <div className="space-y-6">
                  {userOrders.map((order, index) => (
                    <motion.div 
                      key={order.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                      className="border border-gray-200 rounded-lg overflow-hidden"
                    >
                      <div className="bg-gray-50 px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between">
                        <div>
                          <div className="flex items-center">
                            <h3 className="text-lg font-medium text-gray-900">Order #{order.id}</h3>
                            <span className={`ml-3 px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              order.status === 'delivered' ? 'bg-green-100 text-green-800' : 
                              order.status === 'preparing' ? 'bg-yellow-100 text-yellow-800' : 
                              'bg-blue-100 text-blue-800'
                            }`}>
                              {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                            </span>
                          </div>
                          <p className="text-sm text-gray-500 mt-1">
                            {new Date(order.createdAt).toLocaleDateString()} at {new Date(order.createdAt).toLocaleTimeString()}
                          </p>
                        </div>
                        <div className="mt-2 sm:mt-0">
                          <p className="text-lg font-bold text-gray-900">${order.totalAmount.toFixed(2)}</p>
                        </div>
                      </div>
                      
                      <div className="px-6 py-4 border-t border-gray-200">
                        <h4 className="text-sm font-medium text-gray-900 mb-3">Items</h4>
                        <ul className="divide-y divide-gray-200">
                          {order.items.map((item) => (
                            <li key={item.id} className="py-3 flex items-center">
                              <div className="h-10 w-10 flex-shrink-0 rounded-md overflow-hidden">
                                <img 
                                  src={`/images/dishes/dish${parseInt(item.dishId) % 5 + 1}.svg`} 
                                  alt={item.dishName} 
                                  className="h-10 w-10 object-cover"
                                />
                              </div>
                              <div className="ml-4 flex-1">
                                <p className="text-sm font-medium text-gray-900">{item.dishName}</p>
                                <p className="text-sm text-gray-500">${item.price.toFixed(2)} x {item.quantity}</p>
                              </div>
                              <div className="text-sm font-medium text-gray-900">
                                ${(item.price * item.quantity).toFixed(2)}
                              </div>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-between items-center">
                        <div>
                          <p className="text-sm text-gray-500">Delivered to:</p>
                          <p className="text-sm text-gray-900">{order.deliveryAddress}</p>
                        </div>
                        <Link 
                          to={`/orders/${order.id}`} 
                          className="inline-flex items-center px-3 py-1 border border-gray-300 text-sm leading-5 font-medium rounded-md text-gray-700 bg-white hover:text-gray-500 focus:outline-none focus:border-blue-300 focus:shadow-outline-blue active:text-gray-800 active:bg-gray-50 transition ease-in-out duration-150"
                        >
                          View Details
                        </Link>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
          
          {activeTab === 'favorites' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="p-6"
            >
              <h2 className="text-xl font-bold text-gray-900 mb-6">Favorite Dishes</h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(3)].map((_, index) => (
                  <motion.div 
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    whileHover={{ y: -5, transition: { duration: 0.2 } }}
                    className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300"
                  >
                    <Link to={`/dishes/${index + 1}`} className="block">
                      <div className="relative h-48 overflow-hidden">
                        <img 
                          src={`/images/dishes/dish${index + 1}.svg`} 
                          alt={`Favorite Dish ${index + 1}`} 
                          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                        />
                        <div className="absolute top-2 right-2 bg-white rounded-full p-1 shadow-md">
                          <div className="flex items-center text-yellow-500">
                            <Star className="w-4 h-4 fill-current" />
                            <span className="ml-1 text-xs font-medium">{4.5 + index * 0.1}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="p-4">
                        <h3 className="text-lg font-semibold text-gray-800 mb-1">
                          {index === 0 ? "Spaghetti Carbonara" : index === 1 ? "Margherita Pizza" : "Chicken Tikka Masala"}
                        </h3>
                        <p className="text-sm text-gray-500 mb-2">
                          {index === 0 ? "Italian" : index === 1 ? "Italian" : "Indian"}
                        </p>
                        <div className="text-lg font-bold text-orange-500">
                          ${(10 + index * 2).toFixed(2)}
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
          
          {activeTab === 'reviews' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="p-6"
            >
              <h2 className="text-xl font-bold text-gray-900 mb-6">My Reviews</h2>
              
              <div className="space-y-6">
                {[...Array(3)].map((_, index) => (
                  <motion.div 
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="bg-gray-50 p-6 rounded-lg"
                  >
                    <div className="flex items-start">
                      <div className="flex-shrink-0 h-12 w-12 rounded-md overflow-hidden">
                        <img 
                          src={`/images/dishes/dish${index + 1}.svg`} 
                          alt="Dish" 
                          className="h-12 w-12 object-cover"
                        />
                      </div>
                      <div className="ml-4 flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="text-lg font-medium text-gray-900">
                            {index === 0 ? "Spaghetti Carbonara" : index === 1 ? "Margherita Pizza" : "Chicken Tikka Masala"}
                          </h3>
                          <p className="text-sm text-gray-500">
                            {new Date(Date.now() - index * 86400000 * 3).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex items-center mt-1 mb-2">
                          {[...Array(5)].map((_, starIndex) => (
                            <Star 
                              key={starIndex} 
                              className={`w-4 h-4 ${starIndex < 5 - index ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                            />
                          ))}
                          <span className="ml-2 text-sm text-gray-600">{5 - index}.0</span>
                        </div>
                        <p className="text-gray-700">
                          {index === 0 
                            ? "Absolutely delicious! The flavors were amazing and the portion size was perfect. Will definitely order again." 
                            : index === 1 
                            ? "Great dish, but I would have liked a bit more sauce. The pasta was cooked perfectly though!" 
                            : "Decent food, but took longer than expected to arrive. Might try again in the future."}
                        </p>
                        <div className="mt-3 flex justify-end">
                          <button className="text-sm text-orange-500 hover:text-orange-600 font-medium">
                            Edit Review
                          </button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
