import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, Filter, Calendar, ShoppingBag, Clock, CreditCard } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { orders } from '../data/mockData';

const OrderHistory: React.FC = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  
  // If not logged in or not a foodie, show error
  if (!user || user.role !== 'foodie') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Access Denied</h2>
          <p className="text-gray-600 mb-6">You need to be logged in as a foodie to view this page.</p>
          <Link 
            to="/login" 
            className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-md font-medium transition-colors duration-200"
          >
            Login as Foodie
          </Link>
        </div>
      </div>
    );
  }

  // For demo purposes, we'll just use all orders
  const userOrders = orders;
  
  // Filter orders based on status
  const filteredOrders = userOrders.filter(order => {
    if (filterStatus === 'all') return true;
    return order.status === filterStatus;
  });
  
  // Search orders based on dish name
  const searchedOrders = filteredOrders.filter(order => {
    if (!searchTerm) return true;
    return order.items.some(item => 
      item.dishName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });
  
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-gray-900">Order History</h1>
          <p className="mt-2 text-gray-600">View and track all your past and current orders</p>
        </motion.div>
        
        {/* Search and Filter Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="bg-white rounded-lg shadow-md overflow-hidden mb-8"
        >
          <div className="p-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="relative flex-1">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                  placeholder="Search orders by dish name"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="flex items-center">
                <Filter className="h-5 w-5 text-gray-400 mr-2" />
                <label htmlFor="status-filter" className="mr-2 text-sm text-gray-700">
                  Filter by status:
                </label>
                <select
                  id="status-filter"
                  className="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-orange-500 focus:border-orange-500 sm:text-sm rounded-md"
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                >
                  <option value="all">All Orders</option>
                  <option value="pending">Pending</option>
                  <option value="preparing">Preparing</option>
                  <option value="delivering">Delivering</option>
                  <option value="delivered">Delivered</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* Orders List */}
        <div className="space-y-6">
          {searchedOrders.length === 0 ? (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-lg shadow-md p-8 text-center"
            >
              <ShoppingBag className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
              <p className="text-gray-500 mb-6">
                {searchTerm 
                  ? `No orders matching "${searchTerm}" were found.` 
                  : filterStatus !== 'all' 
                    ? `You don't have any ${filterStatus} orders.` 
                    : "You haven't placed any orders yet."}
              </p>
              <Link 
                to="/" 
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-orange-500 hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
              >
                Browse Dishes
              </Link>
            </motion.div>
          ) : (
            searchedOrders.map((order, index) => (
              <motion.div 
                key={order.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="bg-white rounded-lg shadow-md overflow-hidden"
              >
                <div className="bg-gray-50 px-6 py-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <div className="flex items-center">
                        <h3 className="text-lg font-medium text-gray-900">Order #{order.id}</h3>
                        <span className={`ml-3 px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          order.status === 'delivered' ? 'bg-green-100 text-green-800' : 
                          order.status === 'preparing' ? 'bg-yellow-100 text-yellow-800' : 
                          order.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                          'bg-blue-100 text-blue-800'
                        }`}>
                          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </span>
                      </div>
                      <div className="mt-1 flex items-center text-sm text-gray-500">
                        <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        <span>
                          {new Date(order.createdAt).toLocaleDateString()} at {new Date(order.createdAt).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                    <div className="mt-2 sm:mt-0 flex flex-col sm:items-end">
                      <p className="text-lg font-bold text-gray-900">${order.totalAmount.toFixed(2)}</p>
                      <div className="mt-1 flex items-center text-sm text-gray-500">
                        <CreditCard className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        <span>{order.paymentMethod}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="px-6 py-4 border-t border-gray-200">
                  <h4 className="text-sm font-medium text-gray-900 mb-3">Items</h4>
                  <ul className="divide-y divide-gray-200">
                    {order.items.map((item) => (
                      <li key={item.id} className="py-3 flex items-center">
                        <div className="h-16 w-16 flex-shrink-0 rounded-md overflow-hidden">
                          <img 
                            src={`/images/dishes/dish${parseInt(item.dishId) % 5 + 1}.svg`} 
                            alt={item.dishName} 
                            className="h-16 w-16 object-cover"
                          />
                        </div>
                        <div className="ml-4 flex-1">
                          <div className="flex justify-between">
                            <div>
                              <h5 className="text-sm font-medium text-gray-900">{item.dishName}</h5>
                              <p className="mt-1 text-sm text-gray-500">${item.price.toFixed(2)} x {item.quantity}</p>
                            </div>
                            <p className="text-sm font-medium text-gray-900">
                              ${(item.price * item.quantity).toFixed(2)}
                            </p>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
                    <div className="mb-3 sm:mb-0">
                      <p className="text-sm text-gray-500">Delivered to:</p>
                      <p className="text-sm text-gray-900">{order.deliveryAddress}</p>
                    </div>
                    
                    <div className="flex space-x-3">
                      {order.status === 'delivered' && (
                        <button className="inline-flex items-center px-3 py-1 border border-transparent text-sm leading-5 font-medium rounded-md text-white bg-orange-500 hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500">
                          Reorder
                        </button>
                      )}
                      <Link 
                        to={`/orders/${order.id}`} 
                        className="inline-flex items-center px-3 py-1 border border-gray-300 text-sm leading-5 font-medium rounded-md text-gray-700 bg-white hover:text-gray-500 focus:outline-none focus:border-blue-300 focus:shadow-outline-blue active:text-gray-800 active:bg-gray-50 transition ease-in-out duration-150"
                      >
                        View Details
                      </Link>
                    </div>
                  </div>
                </div>
                
                {/* Order Timeline */}
                {order.status !== 'cancelled' && (
                  <div className="px-6 py-4 border-t border-gray-200">
                    <h4 className="text-sm font-medium text-gray-900 mb-4">Order Timeline</h4>
                    <div className="relative">
                      <div className="absolute inset-0 flex items-center" aria-hidden="true">
                        <div className="h-0.5 w-full bg-gray-200"></div>
                      </div>
                      <ul className="relative flex justify-between">
                        <li className="text-center">
                          <div className={`relative w-6 h-6 rounded-full ${
                            ['pending', 'preparing', 'delivering', 'delivered'].includes(order.status) 
                              ? 'bg-orange-500' : 'bg-gray-300'
                          } flex items-center justify-center`}>
                            <Clock className="w-3 h-3 text-white" />
                          </div>
                          <p className="mt-2 text-xs text-gray-500">Ordered</p>
                        </li>
                        <li className="text-center">
                          <div className={`relative w-6 h-6 rounded-full ${
                            ['preparing', 'delivering', 'delivered'].includes(order.status) 
                              ? 'bg-orange-500' : 'bg-gray-300'
                          } flex items-center justify-center`}>
                            <Clock className="w-3 h-3 text-white" />
                          </div>
                          <p className="mt-2 text-xs text-gray-500">Preparing</p>
                        </li>
                        <li className="text-center">
                          <div className={`relative w-6 h-6 rounded-full ${
                            ['delivering', 'delivered'].includes(order.status) 
                              ? 'bg-orange-500' : 'bg-gray-300'
                          } flex items-center justify-center`}>
                            <Clock className="w-3 h-3 text-white" />
                          </div>
                          <p className="mt-2 text-xs text-gray-500">On the way</p>
                        </li>
                        <li className="text-center">
                          <div className={`relative w-6 h-6 rounded-full ${
                            ['delivered'].includes(order.status) 
                              ? 'bg-orange-500' : 'bg-gray-300'
                          } flex items-center justify-center`}>
                            <Clock className="w-3 h-3 text-white" />
                          </div>
                          <p className="mt-2 text-xs text-gray-500">Delivered</p>
                        </li>
                      </ul>
                    </div>
                  </div>
                )}
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default OrderHistory;
