import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, ChevronLeft, Send, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { dishes, reviews } from '../data/mockData';
import toast from 'react-hot-toast';

const Reviews: React.FC = () => {
  const { dishId } = useParams<{ dishId: string }>();
  const { user } = useAuth();
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Find the dish
  const dish = dishes.find(d => d.id === dishId);
  
  // Get reviews for this dish
  const dishReviews = reviews.filter(r => r.dishId === dishId);
  
  // Check if user has already reviewed this dish
  const userReview = user ? dishReviews.find(r => r.userId === user.id) : null;
  
  // Handle star rating click
  const handleRatingChange = (rating: number) => {
    setNewReview(prev => ({ ...prev, rating }));
  };
  
  // Handle comment change
  const handleCommentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNewReview(prev => ({ ...prev, comment: e.target.value }));
  };
  
  // Handle review submission
  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast.error('You must be logged in to submit a review');
      return;
    }
    
    if (!newReview.comment.trim()) {
      toast.error('Please enter a comment for your review');
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      toast.success('Your review has been submitted!');
      setNewReview({ rating: 5, comment: '' });
      setIsSubmitting(false);
    }, 1000);
  };
  
  if (!dish) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Dish Not Found</h2>
          <p className="text-gray-600 mb-6">The dish you're looking for doesn't exist.</p>
          <Link 
            to="/" 
            className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-md font-medium transition-colors duration-200"
          >
            Back to Home
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <Link 
            to={`/dishes/${dishId}`} 
            className="inline-flex items-center text-orange-500 hover:text-orange-600 mb-4"
          >
            <ChevronLeft className="w-5 h-5 mr-1" />
            Back to Dish
          </Link>
          
          <div className="flex items-center">
            <div className="h-16 w-16 flex-shrink-0 rounded-md overflow-hidden mr-4">
              <img 
                src={dish.imageUrl} 
                alt={dish.name} 
                className="h-16 w-16 object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = `/images/dishes/dish${parseInt(dish.id) % 5 + 1}.svg`;
                }}
              />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{dish.name}</h1>
              <div className="flex items-center mt-1">
                <div className="flex items-center text-yellow-500">
                  {[...Array(5)].map((_, index) => (
                    <Star 
                      key={index} 
                      className={`w-4 h-4 ${index < Math.round(dish.rating || 0) ? 'fill-current' : ''}`} 
                    />
                  ))}
                </div>
                <span className="ml-2 text-sm text-gray-600">
                  {dish.rating?.toFixed(1)} ({dishReviews.length} reviews)
                </span>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* Write a Review Section */}
        {user && !userReview && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="bg-white rounded-lg shadow-md overflow-hidden mb-8"
          >
            <div className="px-6 py-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Write a Review</h2>
              
              <form onSubmit={handleSubmitReview}>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Your Rating
                  </label>
                  <div className="flex items-center">
                    {[...Array(5)].map((_, index) => (
                      <button
                        key={index}
                        type="button"
                        onClick={() => handleRatingChange(index + 1)}
                        className="focus:outline-none"
                      >
                        <Star 
                          className={`w-8 h-8 ${
                            index < newReview.rating 
                              ? 'text-yellow-500 fill-current' 
                              : 'text-gray-300'
                          } transition-colors duration-150`} 
                        />
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="mb-4">
                  <label htmlFor="comment" className="block text-sm font-medium text-gray-700 mb-2">
                    Your Review
                  </label>
                  <textarea
                    id="comment"
                    rows={4}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                    placeholder="Share your experience with this dish..."
                    value={newReview.comment}
                    onChange={handleCommentChange}
                    required
                  />
                </div>
                
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className={`inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-500 hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 ${
                      isSubmitting ? 'opacity-75 cursor-not-allowed' : ''
                    }`}
                  >
                    {isSubmitting ? (
                      <>
                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Submitting...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Submit Review
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </motion.div>
        )}
        
        {/* Reviews List */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">
            {dishReviews.length} {dishReviews.length === 1 ? 'Review' : 'Reviews'}
          </h2>
        </div>
        
        {dishReviews.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="bg-white rounded-lg shadow-md p-8 text-center"
          >
            <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No reviews yet</h3>
            <p className="text-gray-500 mb-6">Be the first to review this dish!</p>
            {!user ? (
              <Link 
                to="/login" 
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-orange-500 hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
              >
                Login to Write a Review
              </Link>
            ) : null}
          </motion.div>
        ) : (
          <div className="space-y-6">
            {dishReviews.map((review, index) => (
              <motion.div 
                key={review.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="bg-white rounded-lg shadow-md overflow-hidden"
              >
                <div className="px-6 py-6">
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                        <User className="h-6 w-6 text-gray-500" />
                      </div>
                    </div>
                    <div className="ml-4 flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-medium text-gray-900">{review.userName}</h3>
                        <p className="text-sm text-gray-500">
                          {new Date(review.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center mt-1 mb-2">
                        {[...Array(5)].map((_, starIndex) => (
                          <Star 
                            key={starIndex} 
                            className={`w-4 h-4 ${starIndex < review.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                      <p className="text-sm text-gray-700">{review.comment}</p>
                      
                      {user && review.userId === user.id && (
                        <div className="mt-3 flex justify-end">
                          <button className="text-sm text-orange-500 hover:text-orange-600 font-medium">
                            Edit Review
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Reviews;
