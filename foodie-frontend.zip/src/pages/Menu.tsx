import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Filter, ChevronDown, Star } from 'lucide-react';
import { dishes, Dish } from '../data/mockData';

const Menu: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [sortOption, setSortOption] = useState<string>('default');
  const [filteredDishes, setFilteredDishes] = useState<Dish[]>(dishes);
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Extract unique categories from dishes
  const categories = ['All', ...Array.from(new Set(dishes.map(dish => dish.category)))];

  // Filter and sort dishes based on search term, category, and sort option
  useEffect(() => {
    let result = [...dishes];
    
    // Filter by search term
    if (searchTerm) {
      result = result.filter(dish => 
        dish.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        dish.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Filter by category
    if (selectedCategory !== 'All') {
      result = result.filter(dish => dish.category === selectedCategory);
    }
    
    // Sort dishes
    switch (sortOption) {
      case 'price-low-high':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-high-low':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      default:
        // Default sorting (by id)
        result.sort((a, b) => parseInt(a.id) - parseInt(b.id));
    }
    
    setFilteredDishes(result);
  }, [searchTerm, selectedCategory, sortOption]);

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.4
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
            Our <span className="text-orange-500">Menu</span>
          </h1>
          <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500">
            Explore our delicious dishes prepared by talented chefs.
          </p>
        </motion.div>

        {/* Search and Filter Section */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search Bar */}
            <div className="relative w-full md:w-96">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-orange-500 focus:border-orange-500 transition duration-150 ease-in-out"
                placeholder="Search dishes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
              {/* Category Filter */}
              <div className="relative w-full sm:w-48">
                <button
                  type="button"
                  className="inline-flex justify-between w-full rounded-md border border-gray-300 shadow-sm px-4 py-3 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
                  onClick={() => setIsFilterOpen(!isFilterOpen)}
                >
                  <span>Category: {selectedCategory}</span>
                  <ChevronDown className="h-5 w-5 text-gray-400" />
                </button>

                <AnimatePresence>
                  {isFilterOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.2 }}
                      className="origin-top-right absolute right-0 mt-2 w-full rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10"
                    >
                      <div className="py-1" role="menu" aria-orientation="vertical">
                        {categories.map((category) => (
                          <button
                            key={category}
                            className={`block px-4 py-2 text-sm w-full text-left ${
                              selectedCategory === category
                                ? 'bg-orange-100 text-orange-900'
                                : 'text-gray-700 hover:bg-gray-100'
                            }`}
                            onClick={() => {
                              setSelectedCategory(category);
                              setIsFilterOpen(false);
                            }}
                          >
                            {category}
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Sort Options */}
              <div className="relative w-full sm:w-56">
                <div className="flex">
                  <label htmlFor="sort" className="sr-only">Sort by</label>
                  <select
                    id="sort"
                    name="sort"
                    className="block w-full rounded-md border border-gray-300 shadow-sm px-4 py-3 bg-white text-gray-700 focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                    value={sortOption}
                    onChange={(e) => setSortOption(e.target.value)}
                  >
                    <option value="default">Sort by: Default</option>
                    <option value="price-low-high">Price: Low to High</option>
                    <option value="price-high-low">Price: High to Low</option>
                    <option value="rating">Rating</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-600">
            Showing {filteredDishes.length} {filteredDishes.length === 1 ? 'dish' : 'dishes'}
            {selectedCategory !== 'All' ? ` in ${selectedCategory}` : ''}
            {searchTerm ? ` matching "${searchTerm}"` : ''}
          </p>
        </div>

        {/* Dishes Grid */}
        {filteredDishes.length > 0 ? (
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {filteredDishes.map((dish) => (
              <motion.div
                key={dish.id}
                variants={itemVariants}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
                className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
              >
                <div className="relative h-48 w-full overflow-hidden">
                  <img
                    src={dish.imageUrl}
                    alt={dish.name}
                    className="h-full w-full object-cover transition-transform duration-500 hover:scale-110"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "/images/dishes/dish1.svg";
                    }}
                  />
                  {dish.rating && (
                    <div className="absolute top-2 right-2 bg-white bg-opacity-90 px-2 py-1 rounded-md flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 mr-1" />
                      <span className="text-sm font-medium">{dish.rating}</span>
                    </div>
                  )}
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold text-gray-900 mb-1">{dish.name}</h3>
                    <p className="text-lg font-semibold text-orange-500">${dish.price.toFixed(2)}</p>
                  </div>
                  <p className="text-gray-600 mb-4 line-clamp-2">{dish.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                      {dish.category}
                    </span>
                    <button className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-orange-500 hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 transition-colors duration-200">
                      Add to Cart
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="text-center py-16"
          >
            <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-orange-100 text-orange-500 mb-6">
              <Filter className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">No dishes found</h3>
            <p className="text-gray-600 max-w-md mx-auto">
              We couldn't find any dishes matching your search criteria. Try adjusting your filters or search term.
            </p>
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('All');
                setSortOption('default');
              }}
              className="mt-6 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-orange-700 bg-orange-100 hover:bg-orange-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
            >
              Clear all filters
            </button>
          </motion.div>
        )}

        {/* Chef Spotlight Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-20 bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          <div className="md:flex">
            <div className="md:flex-shrink-0 md:w-1/2">
              <img 
                className="h-full w-full object-cover" 
                src="/images/chefs/photos/chef1.jpg" 
                alt="Featured Chef"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = "/images/chefs/chef1.svg";
                }}
              />
            </div>
            <div className="p-8 md:p-12 md:w-1/2">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Chef Spotlight</h2>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Our featured chef this week is Chef John, an award-winning culinary expert with over 10 years of experience in Italian cuisine. His signature dishes include the delicious Spaghetti Carbonara and Margherita Pizza.
              </p>
              <a 
                href="/chef/1" 
                className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-orange-500 hover:bg-orange-600 transition-colors duration-200"
              >
                View Chef's Dishes
              </a>
            </div>
          </div>
        </motion.div>

        {/* Call to Action */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-16 bg-orange-500 rounded-2xl shadow-xl overflow-hidden"
        >
          <div className="px-6 py-12 md:py-16 md:px-12 text-center">
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl mb-6">
              Ready to place your order?
            </h2>
            <p className="text-lg text-orange-100 mb-8 max-w-3xl mx-auto">
              Create an account or log in to start ordering your favorite dishes from our talented chefs.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <a 
                href="/login" 
                className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-orange-600 bg-white hover:bg-orange-50 transition-colors duration-200"
              >
                Log In
              </a>
              <a 
                href="/register" 
                className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-orange-600 hover:bg-orange-700 transition-colors duration-200"
              >
                Sign Up
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Menu;
