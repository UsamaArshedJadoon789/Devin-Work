import React from 'react';
import { motion } from 'framer-motion';
import { Users, Award, Clock, MapPin, ChefHat, Utensils } from 'lucide-react';

const AboutUs: React.FC = () => {
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
            About <span className="text-orange-500">Foodie</span>
          </h1>
          <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500">
            Connecting food lovers with talented chefs for an exceptional dining experience.
          </p>
        </motion.div>

        {/* Our Story Section */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden mb-16"
        >
          <div className="md:flex">
            <div className="md:flex-shrink-0 md:w-1/2">
              <img 
                className="h-full w-full object-cover" 
                src="/images/chefs/photos/chef1.jpg" 
                alt="Chefs preparing food"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = "/images/chefs/chef1.svg";
                }}
              />
            </div>
            <div className="p-8 md:p-12 md:w-1/2">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Story</h2>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Foodie was born out of a passion for connecting talented chefs with food enthusiasts. Our journey began in 2020 when our founders, all food lovers themselves, realized there was a gap in the market for a platform that could bring restaurant-quality dining experiences to people's homes.
                </p>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  What started as a small operation in a single city has now grown into a nationwide platform with thousands of chefs and even more satisfied customers. Our mission remains the same: to make exceptional food accessible to everyone while supporting talented chefs in sharing their culinary creations.
                </p>
                <p className="text-gray-600 leading-relaxed">
                  Today, Foodie continues to innovate and expand, always with the goal of creating meaningful connections through the universal language of food.
                </p>
              </motion.div>
            </div>
          </div>
        </motion.div>

        {/* Our Values Section */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="mb-16"
        >
          <motion.h2 
            variants={itemVariants}
            className="text-3xl font-bold text-gray-900 text-center mb-12"
          >
            Our Values
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              variants={itemVariants}
              className="bg-white rounded-xl shadow-md p-8 text-center hover:shadow-lg transition-shadow duration-300"
            >
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-orange-100 text-orange-500 mb-6">
                <Award className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Quality First</h3>
              <p className="text-gray-600">
                We believe in delivering exceptional quality in every dish. Our chefs are vetted for their skills and commitment to excellence.
              </p>
            </motion.div>
            
            <motion.div 
              variants={itemVariants}
              className="bg-white rounded-xl shadow-md p-8 text-center hover:shadow-lg transition-shadow duration-300"
            >
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-orange-100 text-orange-500 mb-6">
                <Users className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Community</h3>
              <p className="text-gray-600">
                We foster a community of food lovers and talented chefs, creating connections through shared culinary experiences.
              </p>
            </motion.div>
            
            <motion.div 
              variants={itemVariants}
              className="bg-white rounded-xl shadow-md p-8 text-center hover:shadow-lg transition-shadow duration-300"
            >
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-orange-100 text-orange-500 mb-6">
                <Utensils className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Culinary Innovation</h3>
              <p className="text-gray-600">
                We encourage creativity and innovation in the kitchen, supporting chefs in bringing new and exciting dishes to our platform.
              </p>
            </motion.div>
          </div>
        </motion.div>

        {/* Key Features Section */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Why Choose Foodie</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
              <div className="md:flex">
                <div className="md:flex-shrink-0 p-6 flex items-center justify-center bg-orange-50">
                  <ChefHat className="h-12 w-12 text-orange-500" />
                </div>
                <div className="p-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Expert Chefs</h3>
                  <p className="text-gray-600">
                    Our platform features talented chefs with diverse culinary backgrounds, from home cooks with secret family recipes to professional chefs with years of restaurant experience.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
              <div className="md:flex">
                <div className="md:flex-shrink-0 p-6 flex items-center justify-center bg-orange-50">
                  <Clock className="h-12 w-12 text-orange-500" />
                </div>
                <div className="p-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Convenient Ordering</h3>
                  <p className="text-gray-600">
                    Browse, order, and enjoy delicious meals with just a few clicks. Our user-friendly platform makes the entire process seamless and enjoyable.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
              <div className="md:flex">
                <div className="md:flex-shrink-0 p-6 flex items-center justify-center bg-orange-50">
                  <MapPin className="h-12 w-12 text-orange-500" />
                </div>
                <div className="p-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Local Focus</h3>
                  <p className="text-gray-600">
                    We connect you with chefs in your area, supporting local culinary talent and ensuring your food arrives fresh and delicious.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
              <div className="md:flex">
                <div className="md:flex-shrink-0 p-6 flex items-center justify-center bg-orange-50">
                  <Award className="h-12 w-12 text-orange-500" />
                </div>
                <div className="p-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Quality Guaranteed</h3>
                  <p className="text-gray-600">
                    We stand behind the quality of every dish on our platform. If you're not satisfied, we'll make it right.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Team Section */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="mb-16"
        >
          <motion.h2 
            variants={itemVariants}
            className="text-3xl font-bold text-gray-900 text-center mb-12"
          >
            Meet Our Team
          </motion.h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <motion.div 
              variants={itemVariants}
              className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
            >
              <div className="aspect-w-1 aspect-h-1">
                <img 
                  className="h-full w-full object-cover" 
                  src="/images/chefs/photos/chef1.jpg" 
                  alt="CEO"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "/images/chefs/chef2.svg";
                  }}
                />
              </div>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-1">Michael Chen</h3>
                <p className="text-sm text-orange-500 mb-3">CEO &amp; Co-Founder</p>
                <p className="text-gray-600 text-sm">
                  Former restaurant owner with a passion for connecting people through food.
                </p>
              </div>
            </motion.div>
            
            <motion.div 
              variants={itemVariants}
              className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
            >
              <div className="aspect-w-1 aspect-h-1">
                <img 
                  className="h-full w-full object-cover" 
                  src="/images/chefs/photos/chef2.jpg" 
                  alt="COO"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "/images/chefs/chef3.svg";
                  }}
                />
              </div>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-1">Sarah Johnson</h3>
                <p className="text-sm text-orange-500 mb-3">COO &amp; Co-Founder</p>
                <p className="text-gray-600 text-sm">
                  Operations expert with experience scaling food delivery platforms.
                </p>
              </div>
            </motion.div>
            
            <motion.div 
              variants={itemVariants}
              className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
            >
              <div className="aspect-w-1 aspect-h-1">
                <img 
                  className="h-full w-full object-cover" 
                  src="/images/chefs/photos/chef3.jpg" 
                  alt="CTO"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "/images/chefs/chef4.svg";
                  }}
                />
              </div>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-1">David Rodriguez</h3>
                <p className="text-sm text-orange-500 mb-3">CTO</p>
                <p className="text-gray-600 text-sm">
                  Tech innovator focused on creating seamless digital experiences.
                </p>
              </div>
            </motion.div>
            
            <motion.div 
              variants={itemVariants}
              className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
            >
              <div className="aspect-w-1 aspect-h-1">
                <img 
                  className="h-full w-full object-cover" 
                  src="/images/chefs/photos/chef2.jpg" 
                  alt="Head Chef"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "/images/chefs/chef5.svg";
                  }}
                />
              </div>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-1">Emily Patel</h3>
                <p className="text-sm text-orange-500 mb-3">Head of Culinary</p>
                <p className="text-gray-600 text-sm">
                  Award-winning chef dedicated to maintaining culinary excellence.
                </p>
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* Call to Action */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="bg-orange-500 rounded-2xl shadow-xl overflow-hidden"
        >
          <div className="px-6 py-12 md:py-16 md:px-12 text-center">
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl mb-6">
              Ready to experience exceptional food?
            </h2>
            <p className="text-lg text-orange-100 mb-8 max-w-3xl mx-auto">
              Join thousands of food lovers who have discovered their new favorite dishes through Foodie.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <a 
                href="/" 
                className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-orange-600 bg-white hover:bg-orange-50 transition-colors duration-200"
              >
                Browse Dishes
              </a>
              <a 
                href="/contact" 
                className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-orange-600 hover:bg-orange-700 transition-colors duration-200"
              >
                Contact Us
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AboutUs;
