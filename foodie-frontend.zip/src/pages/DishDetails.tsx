import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Star, Clock, ChefHat, Plus, Minus, ShoppingCart } from 'lucide-react';
import { dishes, users } from '../data/mockData';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const DishDetails: React.FC = () => {
  const { dishId } = useParams<{ dishId: string }>();
  const { addToCart } = useCart();
  const { user } = useAuth();
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('description');
  
  // Find the dish based on the ID from the URL
  const dish = dishes.find(d => d.id === dishId);
  
  // Find the chef who created this dish
  const chef = dish ? users.find(u => u.id === dish.chefId) : null;
  
  // If dish not found, show error
  if (!dish) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Dish Not Found</h2>
          <p className="text-gray-600 mb-6">The dish you're looking for doesn't exist or has been removed.</p>
          <Link 
            to="/dishes" 
            className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-md font-medium transition-colors duration-200"
          >
            Browse Dishes
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(dish, quantity);
    // Reset quantity after adding to cart
    setQuantity(1);
  };

  const incrementQuantity = () => {
    setQuantity(prev => prev + 1);
  };

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Link 
            to="/dishes" 
            className="inline-flex items-center text-gray-600 hover:text-orange-500 transition-colors duration-200"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dishes
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="md:flex">
            {/* Dish Image */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="md:w-1/2"
            >
              <div className="relative h-64 md:h-full">
                <img 
                  src={dish.imageUrl} 
                  alt={dish.name} 
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = '/images/dishes/dish1.svg';
                  }}
                />
                <div className="absolute top-4 right-4 bg-white rounded-full p-2 shadow-md">
                  <div className="flex items-center text-yellow-500">
                    <Star className="w-5 h-5 fill-current" />
                    <span className="ml-1 font-medium">{dish.rating || 4.5}</span>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Dish Info */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="md:w-1/2 p-6"
            >
              <div className="mb-4">
                <span className="inline-block bg-orange-100 text-orange-800 text-xs px-2 py-1 rounded-full uppercase font-semibold tracking-wide">
                  {dish.category}
                </span>
              </div>
              
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{dish.name}</h1>
              
              <div className="flex items-center mb-4">
                {dish.preparationTime && (
                  <div className="flex items-center text-gray-600 mr-4">
                    <Clock className="w-4 h-4 mr-1" />
                    <span className="text-sm">{dish.preparationTime} min</span>
                  </div>
                )}
                
                {chef && (
                  <Link 
                    to={`/chefs/${chef.id}`} 
                    className="flex items-center text-gray-600 hover:text-orange-500 transition-colors duration-200"
                  >
                    <ChefHat className="w-4 h-4 mr-1" />
                    <span className="text-sm">{chef.name}</span>
                  </Link>
                )}
              </div>
              
              <div className="text-2xl font-bold text-orange-500 mb-6">${dish.price.toFixed(2)}</div>
              
              {/* Tabs */}
              <div className="mb-6">
                <div className="flex border-b border-gray-200">
                  <button
                    onClick={() => setActiveTab('description')}
                    className={`py-2 px-4 text-sm font-medium ${
                      activeTab === 'description'
                        ? 'text-orange-500 border-b-2 border-orange-500'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    Description
                  </button>
                  <button
                    onClick={() => setActiveTab('ingredients')}
                    className={`py-2 px-4 text-sm font-medium ${
                      activeTab === 'ingredients'
                        ? 'text-orange-500 border-b-2 border-orange-500'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    Ingredients
                  </button>
                  <button
                    onClick={() => setActiveTab('reviews')}
                    className={`py-2 px-4 text-sm font-medium ${
                      activeTab === 'reviews'
                        ? 'text-orange-500 border-b-2 border-orange-500'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    Reviews
                  </button>
                </div>
                
                <div className="py-4">
                  {activeTab === 'description' && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <p className="text-gray-700">{dish.description}</p>
                      <p className="text-gray-700 mt-2">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, 
                        nunc sit amet ultricies lacinia, nisl nisl aliquam nisl, eget aliquam
                        nisl nisl sit amet nisl. Sed euismod, nunc sit amet ultricies lacinia.
                      </p>
                    </motion.div>
                  )}
                  
                  {activeTab === 'ingredients' && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <ul className="list-disc pl-5 text-gray-700 space-y-1">
                        <li>Fresh pasta</li>
                        <li>Eggs</li>
                        <li>Pancetta or bacon</li>
                        <li>Parmesan cheese</li>
                        <li>Black pepper</li>
                        <li>Salt</li>
                        <li>Olive oil</li>
                      </ul>
                    </motion.div>
                  )}
                  
                  {activeTab === 'reviews' && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="space-y-4">
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <div className="flex items-center mb-2">
                            <div className="flex items-center text-yellow-500 mr-2">
                              <Star className="w-4 h-4 fill-current" />
                              <Star className="w-4 h-4 fill-current" />
                              <Star className="w-4 h-4 fill-current" />
                              <Star className="w-4 h-4 fill-current" />
                              <Star className="w-4 h-4 fill-current" />
                            </div>
                            <span className="font-medium text-gray-800">John Doe</span>
                            <span className="text-gray-500 text-sm ml-2">2 days ago</span>
                          </div>
                          <p className="text-gray-700">
                            Absolutely delicious! The flavors were amazing and the portion size was perfect.
                            Will definitely order again.
                          </p>
                        </div>
                        
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <div className="flex items-center mb-2">
                            <div className="flex items-center text-yellow-500 mr-2">
                              <Star className="w-4 h-4 fill-current" />
                              <Star className="w-4 h-4 fill-current" />
                              <Star className="w-4 h-4 fill-current" />
                              <Star className="w-4 h-4 fill-current" />
                              <Star className="w-4 h-4" />
                            </div>
                            <span className="font-medium text-gray-800">Jane Smith</span>
                            <span className="text-gray-500 text-sm ml-2">1 week ago</span>
                          </div>
                          <p className="text-gray-700">
                            Great dish, but I would have liked a bit more sauce. The pasta was cooked perfectly though!
                          </p>
                        </div>
                        
                        <Link 
                          to={`/dishes/${dish.id}/reviews`} 
                          className="text-orange-500 hover:text-orange-600 font-medium inline-block mt-2"
                        >
                          View all reviews
                        </Link>
                      </div>
                    </motion.div>
                  )}
                </div>
              </div>
              
              {/* Add to Cart Section (only for foodies) */}
              {user?.role === 'foodie' && (
                <div className="mt-6">
                  <div className="flex items-center mb-4">
                    <button
                      onClick={decrementQuantity}
                      className="bg-gray-200 hover:bg-gray-300 text-gray-800 w-10 h-10 rounded-full flex items-center justify-center transition-colors duration-200"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="mx-4 font-medium text-lg w-8 text-center">{quantity}</span>
                    <button
                      onClick={incrementQuantity}
                      className="bg-gray-200 hover:bg-gray-300 text-gray-800 w-10 h-10 rounded-full flex items-center justify-center transition-colors duration-200"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleAddToCart}
                    className="w-full bg-orange-500 hover:bg-orange-600 text-white py-3 rounded-md font-medium flex items-center justify-center transition-colors duration-200"
                  >
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    Add to Cart - ${(dish.price * quantity).toFixed(2)}
                  </motion.button>
                </div>
              )}
            </motion.div>
          </div>
        </div>
        
        {/* Related Dishes Section */}
        <section className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">You Might Also Like</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {dishes
              .filter(d => d.id !== dish.id && d.category === dish.category)
              .slice(0, 4)
              .map((relatedDish) => (
                <motion.div
                  key={relatedDish.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  whileHover={{ y: -5, transition: { duration: 0.2 } }}
                  className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300"
                >
                  <Link to={`/dishes/${relatedDish.id}`} className="block">
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={relatedDish.imageUrl} 
                        alt={relatedDish.name} 
                        className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = '/images/dishes/dish1.svg';
                        }}
                      />
                      <div className="absolute top-2 right-2 bg-white rounded-full p-1 shadow-md">
                        <div className="flex items-center text-yellow-500">
                          <Star className="w-4 h-4 fill-current" />
                          <span className="ml-1 text-xs font-medium">{relatedDish.rating || 4.5}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-4">
                      <h3 className="text-lg font-semibold text-gray-800 mb-1">{relatedDish.name}</h3>
                      <p className="text-sm text-gray-500 mb-2">{relatedDish.category}</p>
                      <div className="text-lg font-bold text-orange-500">${relatedDish.price.toFixed(2)}</div>
                    </div>
                  </Link>
                </motion.div>
              ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default DishDetails;
