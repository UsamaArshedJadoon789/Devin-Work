import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, Clock, Plus } from 'lucide-react';
import { Dish } from '../data/mockData';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

interface DishCardProps {
  dish: Dish;
}

const DishCard: React.FC<DishCardProps> = ({ dish }) => {
  const { addToCart } = useCart();
  const { user } = useAuth();
  
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(dish, 1);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -5, transition: { duration: 0.2 } }}
      className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300"
    >
      <Link to={`/dishes/${dish.id}`} className="block">
        <div className="relative h-48 overflow-hidden">
          <img 
            src={dish.imageUrl} 
            alt={dish.name} 
            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = '/images/dishes/dish1.svg';
            }}
          />
          <div className="absolute top-2 right-2 bg-white rounded-full p-1 shadow-md">
            <div className="flex items-center text-yellow-500">
              <Star className="w-4 h-4 fill-current" />
              <span className="ml-1 text-xs font-medium">{dish.rating || 4.5}</span>
            </div>
          </div>
          {dish.preparationTime && (
            <div className="absolute bottom-2 left-2 bg-white rounded-full px-2 py-1 shadow-md flex items-center">
              <Clock className="w-3 h-3 text-gray-600" />
              <span className="ml-1 text-xs font-medium text-gray-600">{dish.preparationTime} min</span>
            </div>
          )}
        </div>
        
        <div className="p-4">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-1">{dish.name}</h3>
              <p className="text-sm text-gray-500 mb-2">{dish.category}</p>
            </div>
            <div className="text-lg font-bold text-orange-500">${dish.price.toFixed(2)}</div>
          </div>
          
          <p className="text-sm text-gray-600 mb-4 line-clamp-2">{dish.description}</p>
          
          {user?.role === 'foodie' && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleAddToCart}
              className="w-full bg-orange-500 hover:bg-orange-600 text-white py-2 rounded-md flex items-center justify-center transition-colors duration-200"
            >
              <Plus className="w-4 h-4 mr-1" />
              Add to Cart
            </motion.button>
          )}
        </div>
      </Link>
    </motion.div>
  );
};

export default DishCard;
